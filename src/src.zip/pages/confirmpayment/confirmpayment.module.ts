import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConfirmpaymentPage } from './confirmpayment';

@NgModule({
  declarations: [
    ConfirmpaymentPage,
  ],
  imports: [
    IonicPageModule.forChild(ConfirmpaymentPage),
  ],
})
export class ConfirmpaymentPageModule {}
