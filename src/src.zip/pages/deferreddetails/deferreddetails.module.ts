import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DeferreddetailsPage } from './deferreddetails';

@NgModule({
  declarations: [
    DeferreddetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(DeferreddetailsPage),
  ],
})
export class DeferreddetailsPageModule {}
