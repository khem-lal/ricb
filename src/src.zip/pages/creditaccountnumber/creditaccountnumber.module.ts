import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CreditaccountnumberPage } from './creditaccountnumber';

@NgModule({
  declarations: [
    CreditaccountnumberPage,
  ],
  imports: [
    IonicPageModule.forChild(CreditaccountnumberPage),
  ],
})
export class CreditaccountnumberPageModule {}
