import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ImmediatedetailsPage } from './immediatedetails';

@NgModule({
  declarations: [
    ImmediatedetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ImmediatedetailsPage),
  ],
})
export class ImmediatedetailsPageModule {}
