import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PolicynumberPage } from './policynumber';

@NgModule({
  declarations: [
    PolicynumberPage,
  ],
  imports: [
    IonicPageModule.forChild(PolicynumberPage),
  ],
})
export class PolicynumberPageModule {}
